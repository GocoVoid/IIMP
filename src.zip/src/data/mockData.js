// ─────────────────────────────────────────────
//  IIMP — Central Mock Data
// ─────────────────────────────────────────────

export const MOCK_USERS = [
  { id: 1001, fullName: 'Tushar Mukherjee',  email: 'tushar.mukherjee@pratiti.com',  role: 'EMPLOYEE',      department: 'IT',         status: 'ACTIVE' },
  { id: 1002, fullName: 'Priya Sharma',       email: 'priya.sharma@pratiti.com',       role: 'SUPPORT_STAFF', department: 'IT',         status: 'ACTIVE' },
  { id: 1003, fullName: 'Rahul Desai',        email: 'rahul.desai@pratiti.com',        role: 'SUPPORT_STAFF', department: 'HR',         status: 'ACTIVE' },
  { id: 1004, fullName: 'Anita Nair',         email: 'anita.nair@pratiti.com',         role: 'SUPPORT_STAFF', department: 'Admin',      status: 'ACTIVE' },
  { id: 1005, fullName: 'Vikram Joshi',       email: 'vikram.joshi@pratiti.com',       role: 'MANAGER',       department: 'IT',         status: 'ACTIVE' },
  { id: 1006, fullName: 'Sneha Kulkarni',     email: 'sneha.kulkarni@pratiti.com',     role: 'MANAGER',       department: 'HR',         status: 'ACTIVE' },
  { id: 1007, fullName: 'Arjun Mehta',        email: 'arjun.mehta@pratiti.com',        role: 'ADMIN',         department: 'IT',         status: 'ACTIVE' },
  { id: 1008, fullName: 'Kavya Reddy',        email: 'kavya.reddy@pratiti.com',        role: 'EMPLOYEE',      department: 'Finance',    status: 'ACTIVE' },
  { id: 1009, fullName: 'Rohan Patil',        email: 'rohan.patil@pratiti.com',        role: 'EMPLOYEE',      department: 'HR',         status: 'INACTIVE' },
  { id: 1010, fullName: 'Meera Iyer',         email: 'meera.iyer@pratiti.com',         role: 'SUPPORT_STAFF', department: 'Facilities', status: 'ACTIVE' },
];

export const CATEGORIES = ['IT', 'HR', 'Admin', 'Facilities', 'Finance', 'Others'];

export const MOCK_TICKETS = [
  {
    id: 'IIMP-2025-000001',
    title: 'VPN not connecting from home network',
    category: 'IT',
    priority: 'High',
    status: 'In Progress',
    description: 'Unable to connect to company VPN from home. Getting authentication error.',
    createdBy: 1001,
    assignedTo: 1002,
    department: 'IT',
    slaDueAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    isSlaBreached: true,
    createdAt: new Date(Date.now() - 26 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString(),
    resolvedAt: null,
    closedAt: null,
    comments: [
      { id: 1, author: 'Priya Sharma', text: 'Looking into the VPN gateway logs now.', createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString() },
    ],
    attachments: [],
  },
  {
    id: 'IIMP-2025-000002',
    title: 'Laptop keyboard keys not responding',
    category: 'IT',
    priority: 'Medium',
    status: 'Open',
    description: 'Several keys on my laptop keyboard stopped working after a software update.',
    createdBy: 1001,
    assignedTo: null,
    department: 'IT',
    slaDueAt: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString(),
    isSlaBreached: false,
    createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    resolvedAt: null,
    closedAt: null,
    comments: [],
    attachments: [],
  },
  {
    id: 'IIMP-2025-000003',
    title: 'Leave balance not updated in portal',
    category: 'HR',
    priority: 'Low',
    status: 'Resolved',
    description: 'My annual leave balance has not been updated after approved leave last month.',
    createdBy: 1008,
    assignedTo: 1003,
    department: 'HR',
    slaDueAt: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    isSlaBreached: false,
    createdAt: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    resolvedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    closedAt: null,
    comments: [],
    attachments: [],
  },
  {
    id: 'IIMP-2025-000004',
    title: 'Office AC not working in Block B',
    category: 'Facilities',
    priority: 'High',
    status: 'Open',
    description: 'Air conditioning unit in Block B, 3rd floor has stopped working.',
    createdBy: 1001,
    assignedTo: null,
    department: 'Facilities',
    slaDueAt: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
    isSlaBreached: false,
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    resolvedAt: null,
    closedAt: null,
    comments: [],
    attachments: [],
  },
  {
    id: 'IIMP-2025-000005',
    title: 'Printer on Floor 2 showing offline',
    category: 'IT',
    priority: 'Low',
    status: 'Closed',
    description: 'The shared printer on Floor 2 is showing offline status.',
    createdBy: 1008,
    assignedTo: 1002,
    department: 'IT',
    slaDueAt: new Date(Date.now() - 96 * 60 * 60 * 1000).toISOString(),
    isSlaBreached: false,
    createdAt: new Date(Date.now() - 120 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    resolvedAt: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString(),
    closedAt: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    comments: [],
    attachments: [],
  },
  {
    id: 'IIMP-2025-000006',
    title: 'Reimbursement form not submitting',
    category: 'Finance',
    priority: 'Medium',
    status: 'In Progress',
    description: 'The expense reimbursement form throws a server error on submission.',
    createdBy: 1008,
    assignedTo: 1002,
    department: 'IT',
    slaDueAt: new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString(),
    isSlaBreached: false,
    createdAt: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    resolvedAt: null,
    closedAt: null,
    comments: [],
    attachments: [],
  },
  {
    id: 'IIMP-2025-000007',
    title: 'Network issue in conference room 3',
    category: 'IT',
    priority: 'Critical',
    status: 'Open',
    description: 'No network connectivity in conference room 3. Affecting all meetings.',
    createdBy: 1001,
    assignedTo: null,
    department: 'IT',
    slaDueAt: new Date(Date.now() + 1 * 60 * 60 * 1000).toISOString(),
    isSlaBreached: false,
    createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    resolvedAt: null,
    closedAt: null,
    comments: [],
    attachments: [],
  },
  {
    id: 'IIMP-2025-000008',
    title: 'Cafeteria billing system error',
    category: 'Others',
    priority: 'Medium',
    status: 'Open',
    description: 'Cafeteria billing system is throwing errors for card payments.',
    createdBy: 1001,
    assignedTo: null,
    department: null,
    slaDueAt: null,
    isSlaBreached: false,
    createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    resolvedAt: null,
    closedAt: null,
    comments: [],
    attachments: [],
  },
  {
    id: 'IIMP-2025-000009',
    title: 'Unable to login in Software',
    category: 'IT',
    priority: 'High',
    status: 'Open',
    description: 'Tried using correct username password but not working',
    createdBy: 1001,
    assignedTo: null,
    department: 'IT',
    slaDueAt: new Date(Date.now() + 6 * 60 * 60 * 1000).toISOString(),
    isSlaBreached: false,
    createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    resolvedAt: null,
    closedAt: null,
    comments: [],
    attachments: [],
  },
];

export const MOCK_NOTIFICATIONS = [
  { id: 1, message: 'Your ticket IIMP-2025-000001 has been assigned to Priya Sharma.', isRead: false, createdAt: new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString() },
  { id: 2, message: 'SLA breach detected on IIMP-2025-000001.', isRead: false, createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString() },
  { id: 3, message: 'Your ticket IIMP-2025-000003 has been resolved.', isRead: true,  createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString() },
];

export const MOCK_SLA_CONFIG = [
  { id: 1, priority: 'Low',      resolutionTimeHours: 72 },
  { id: 2, priority: 'Medium',   resolutionTimeHours: 48 },
  { id: 3, priority: 'High',     resolutionTimeHours: 24 },
  { id: 4, priority: 'Critical', resolutionTimeHours: 4  },
];

export const MOCK_REPORTS = {
  ticketVolume: [
    { label: 'Mon', count: 8  },
    { label: 'Tue', count: 14 },
    { label: 'Wed', count: 11 },
    { label: 'Thu', count: 17 },
    { label: 'Fri', count: 9  },
    { label: 'Sat', count: 3  },
    { label: 'Sun', count: 2  },
  ],
  categoryBreakdown: [
    { label: 'IT',         count: 24 },
    { label: 'HR',         count: 12 },
    { label: 'Admin',      count: 8  },
    { label: 'Facilities', count: 6  },
    { label: 'Finance',    count: 10 },
    { label: 'Others',     count: 4  },
  ],
  slaCompliance: 78,
  totalToday: 17,
  openCount: 9,
  breachedCount: 3,
};

/* ── Static category + priority + status constants ── */

/**
 * DEPARTMENTS_MAP defines the hierarchical structure:
 * Department → [Sub-categories]
 */
export const DEPARTMENTS_MAP = {
  IT: [
    'Hardware Issues',
    'Software Issues',
    'Network Security & Connectivity',
    'Server & Cloud',
  ],
  HR: [
    'Payroll & Compensation',
    'Leave & Attendance',
    'Benefits & Perks',
    'Onboarding/Offboarding',
    'Employee Relations',
  ],
  Admin: [
    'Workspace & Furniture',
    'Facilities & Maintenance',
    'Office Supplies',
    'Meeting & Event Logistics',
  ],
  Facilities: [
    'HVAC and Climate Control',
    'Plumbing and Electrical',
    'Janitorial and Sanitation',
    'Structural Maintenance',
  ],
  Finance: [
    'Travel & Expenses',
    'Procurement & Vendors',
    'Budgets & Approvals',
    'Corporate Cards',
    'Tax & Audits',
  ],
};

export const DEPARTMENT_NAMES = Object.keys(DEPARTMENTS_MAP);

/* Flat CATEGORY_LIST derived from DEPARTMENTS_MAP for backward-compat */
let _catId = 1;
export const CATEGORY_LIST = [
  ...Object.entries(DEPARTMENTS_MAP).flatMap(([dept, subs]) =>
    subs.map(sub => ({ id: _catId++, categoryName: sub, departmentName: dept }))
  ),
  { id: _catId++, categoryName: 'Others', departmentName: 'Others' },
];

export const CATEGORY_NAMES = CATEGORY_LIST.map(c => c.categoryName);
export const PRIORITIES     = ['Low', 'Medium', 'High', 'Critical'];
export const STATUSES       = ['Open', 'In Progress', 'Resolved', 'Closed'];
